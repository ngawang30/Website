/**
 * @author Ngawang Rinchen
 * @since 12/19/19
 * @version 1.0
 *
 */

package hindialphabetstudy;

import java.io.File;
import java.util.Scanner;
import java.util.Random;
public class HindiAlphabetStudy{
    static Scanner reader;

public static void main(String[] args) throws Exception{
    
    Scanner sc = new Scanner(new File("../HindiAlphabetEnglish.txt"));
    final int MAX = 66;
    String[] alphabet = new String[MAX];
    int [] trouble = new int[MAX];
    int counter =0, repetition;
    reader = new Scanner(System.in);
    
    while(sc.hasNext()){
        alphabet[counter] = sc.next();
        counter++;
    }
    
    System.out.println("How many repetitions would you like to do?");
    repetition = reader.nextInt();
    System.out.println();
    test(alphabet, trouble,repetition);
    troubleOrder(alphabet, trouble);
    graph(alphabet, trouble);
    
}

public static void test(String [] x, int [] y, int rep){
    int correct =0 , incorrect=0, counter =0;
    Random rn = new Random();
    String temp;
    char cori;
    
    for(int i=0; i<x.length; i++){
        int random = rn.nextInt(x.length-counter);
        
        System.out.println(x[random] + ".  Did you get that correct? c/i");
        cori = reader.next().charAt(0);
        
        if(cori == 'c'){
            correct++;
            
            
        } else{
            incorrect++;
            y[random]++;
        }
        
        System.out.println();
        
        x[random] = x[x.length-1-counter];
        
        counter++;
    }
       
    
     

    System.out.println("You got " + correct +" correct and " + incorrect + " incorrect.");
}

public static void troubleOrder(String[] x, int [] y){

    for(int i =0; i<x.length; i++){
        for(int j= 0; j < x.length-1-i; j++){
            
            if(y[j] < y[j+1]){
            int temp = y[j];
            y[j] = y[j+1];
            y[j+1] = temp;
            String temp2 = x[j];
            x[j] = x[j+1];
            x[j+1] = temp2;
            }
            
        }
    
    } // ends for-loop
    
    if(y[0] ==0){
        System.out.println("\nYou got everything right.");
    } else {
        System.out.println("You had the most trouble with: " + x[0]);
    }
    
}

public static void graph(String [] x, int [] y){
    int counter =0;
    System.out.println("\nWould you like a graph? y/n ");
    char response = reader.next().charAt(0);
    if (response == 'y'){
        do{
            System.out.print("\n");
            System.out.print(x[counter]+" ");
            for(int i=0; i < y[counter]; i++){
                System.out.print("*");
            }
            
        counter++;
        }while(y[counter] !=0);
        
    }
    
}


}