/**
 * @author Ngawang Rinchne
 * @since 09/19/19
 * @version 1.0 
 * Description:  This program takes in two variables, desired dosage and 
 * weight and returns the drip rate that should be administered.  Additionally, 
 * in part two, when given a patient's weight, we return a table that informs 
 * them of the drip rate when choosing a desired dosage.  This project has been 
 * the most involved thus far, and therefore, the most enjoyable.  The use of 
 * if statements within while statements and the handling of many variables at
 * once was tricky, but also very engaging. Additionally, this was the first 
 * time that I employed an additional method besides main that actually took 
 * parameters and returned something.  This new piece really helped make my 
 * code more readable, and I hope to employ this to further simply my code 
 * in future projects.
 */
package drip;

import java.util.Scanner;
import java.io.PrintStream;

public class Drip {

    public static void main(String[] args) throws Exception {
        final int DROPNUMBER = 60;
        final double CONCENTRATION = .8;
        int dose = 1, weight = 1;

        Scanner sc = new Scanner(System.in);
        PrintStream ps = new PrintStream("ABC.txt");
        
        System.out.println("Enter the desired dose in mcg/kg/min");
        ps.println("Enter the desired dose in mcg/kg/min");
        System.out.println("When you are done entering data,"
                + " please input a zero");
        ps.println("When you are done entering data, please input a zero");
        System.out.print("Enter an integer between 5 and 10: ");
        ps.print("Enter an integer between 5 and 10: ");

        while (dose > 0) {
            dose = sc.nextInt();
            ps.print(dose);
            if (dose == 0) {

            } else if (dose < 5) {
                System.out.print("\nToo small. Try again." + 
                        "\n\nEnter an integer between 5 and 10: ");
                ps.print("\nToo small. Try again." + 
                        "\n\nEnter an integer between 5 and 10: ");
            } else if (dose > 10) {
                System.out.print("\nToo Large.  Try again." + 
                        "\n\nEnter an integer between 5 and 10: ");
                ps.print("\nToo Large.  Try again." + 
                        "\n\nEnter an integer between 5 and 10: ");
            } else {
                System.out.print("\nEnter the patient's weight in kg: ");
                ps.print("\nEnter the patient's weight in kg: ");
                weight = sc.nextInt();
                ps.print(weight);

                System.out.printf("%nAdminister %.2f drops per minute%n", 
                        getGTT(dose,weight));
                ps.printf("%nAdminister %.2f drops per minute%n", 
                        getGTT(dose,weight));
                System.out.println("\nEnter another desired dosage, "
                        + "or press zero to move to part 2");
                ps.println("\nEnter another desired dosage,"
                        + " or press zero to move to part 2");
            }

        }
        //Part 2
        System.out.print("\nEnter the patient's weight in kg: ");
        ps.print("\nEnter the patient's weight in kg: ");
        weight = sc.nextInt();
        while (weight > 0) {
            ps.println(weight);
            dose = 5;

            System.out.println("\n Dose(mg/kg/min) \t   GTT per minute");
            ps.println("\n Dose(mg/kg/min) \t   GTT per minute");
            while (dose < 11) {
                System.out.printf("\t" + dose + "\t\t\t%.2f%n",
                        getGTT(dose,weight));
                ps.printf("\t " + dose + "\t\t\t%.2f%n", 
                        getGTT(dose,weight));
                dose++;
                
            }
            System.out.print("\nEnter another weight,"
                    + " or press zero to terminate\n");
            ps.print("\nEnter another weight,"
                    + " or press zero to terminate\n");
            weight = sc.nextInt();
                    
        }

    }

    public static double getGTT(int dose, int weight) {
        double desiredDrip;
        desiredDrip = (weight * dose * Math.pow(10, -3)) * (60 / .8);
        return (desiredDrip);
    }
}
